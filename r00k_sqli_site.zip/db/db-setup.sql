# noinspection SqlNoDataSourceInspectionForFile

/*

Initial data for the initial demo database.

docker logs mysql 2>&1 | grep -i password

mysql -h 127.0.0.1 -u root -p < start.sql

*/

-- Get rid of previous test data before generating default test data

drop database if exists t_web_app;
drop user if exists web_admin;
drop user if exists web_user;

-- Create the Database

create database t_web_app;
create database secrets;

-- Set the created database as our target database for commands

use t_web_app;

-- Create a users to use the database

create user 'web_admin'@'%' identified by 'admin_foobar';
grant all privileges on t_web_app.* to 'web_admin'@'%';
grant all privileges on secrets.* to 'web_admin'@'%';

-- Create a directory table to hold values for user contact info

create table directory (
    id int(2) unsigned zerofill not null auto_increment primary key,
    fname varchar(32),
    lname varchar(64),
    email varchar(128),
    affiliation varchar(32),
    active boolean
);

-- Create director specific user

create user 'directory_user'@'%' identified by 'user_foobar';
grant select on t_web_app.directory to 'directory_user'@'%';

-- Create a users table for usernames and passwords

create table users (
    id int(2) unsigned zerofill not null auto_increment primary key,
    username varchar(255),
    password varchar(64),
    email varchar(128)
);

-- Create comments table for use by a web page comments section

create table comments (
    id int(3) unsigned zerofill not null auto_increment primary key,
    email varchar(128),
    comment_text varchar(512)
);

-- create test data for directory table

insert into directory (fname, lname, email, affiliation, active) values ('amos', 'burton', 'amos@roci.net', 'rocinante', true);
insert into directory (fname, lname, email, affiliation, active) values ('james', 'holden', 'jim@roci.net', 'rocinante', true);
insert into directory (fname, lname, email, affiliation, active) values ('naomi', 'nagata', 'naomi@roci.net', 'rocinante', true);
insert into directory (fname, lname, email, affiliation, active) values ('roberta', 'draper', 'bobbie@roci.net', 'rocinante', true);
insert into directory (fname, lname, email, affiliation, active) values ('alex', 'kamal', 'alex@roci.net', 'rocinante', true);
insert into directory (fname, lname, email, affiliation, active) values ('roberta', 'draper', 'r.draper@mcrn.mil', 'mcrn', false);
insert into directory (fname, lname, email, affiliation, active) values ('alex', 'kamal', 'a.kamal@mcrn.mil', 'mcrn', false);
insert into directory (fname, lname, email, affiliation, active) values ('chrisjen', 'avasarala', 'chrissie@un.gov', 'un', true);
insert into directory (fname, lname, email, affiliation, active) values ('james', 'holden', 'jholden@unn.mil', 'unn', false);

-- create test data for users table

insert into users (username, password, email) values ('aburton', 'peaches', 'amos@roci.net');
insert into users (username, password, email) values ('jholden', 'coffee', 'jim@roci.net');
insert into users (username, password, email) values ('nnagata', 'beltalowda', 'naomi@roci.net');
insert into users (username, password, email) values ('rdraper', 'goliath', 'bobbie@roci.net');
insert into users (username, password, email) values ('akamal', 'roci', 'alex@roci.net');
insert into users (username, password, email) values ('r.draper', 'g0l14th', 'r.draper@mcrn.mil');
insert into users (username, password, email) values ('a.kamal', 'pilotslife4me', 'a.kamal@mcrn.mil');
insert into users (username, password, email) values ('chrissie', 'impolitewords', 'chrissie@un.gov');
insert into users (username, password, email) values ('jholden', 'montana', 'jholden@unn.mil');

-- create test data for comments table

insert into comments (email, comment_text) values ('jim@roce.net', 'How are we already out of coffee? Did we not stock up at the last port?');
insert into comments (email, comment_text) values ('amos@roce.net', 'PDC 3 is sticking again, get to it tomorrow.');

-- creat secrets database stuff

use secrets;

create table top_secret (
    id int(3) unsigned zerofill not null auto_increment primary key,
    user varchar(128),
    role varchar(512)
);

insert into top_secret (user, role) values ('cghazi', 'Head of Avasarala security detail');
insert into top_secret (user, role) values ('jpmao', 'Shadow owner of Protogen');
insert into top_secret (user, role) values ('Roma', 'Ganymede hacker. gws access="AKIA2P45X2Y2HJSCPXGR", secret="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"');