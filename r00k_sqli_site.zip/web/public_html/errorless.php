<h2>
Tachi Crew Directory - Errorless
</h2>

Crew directory search. Enter first name of crew member and the matching name and email address will return.

<br /><br />

<form actions="errorless.php" method="post">
Name: <input type="text" name="search" size=70 /><br /><br />
<input type="submit" value="Submit" />
</form>

<br /><br />

<?php

if ( isset($_POST['search']) ) {
    require_once 'config.inc.php';

    $search = $_POST['search'];

    $sql = "select fname,email from directory where fname = '$search';";
    $result = $conn->query($sql);

#    if ($conn->error)
#    {
#        echo "Error: " . $conn->error . "\n";
#    }


    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "Name:\t" . $row['fname'] . "<br />\n";
            echo "Email:\t" . $row['email'] . "<br /><br />\n";
        }
    }
    elseif ($result->num_rows == 0)
    {
        echo "0 results";
    }

    echo "<br />\n";

    $conn->close();

}

?>

<br />
<br />
