<h2>
Tachi Admin Interface
</h2>

Administrator Login Page

<br /><br />

<form actions="login.php" method="post">
Username: <input type="text" name="user" size=70 /><br /><br />
Password: <input type="password" name="password" size=70 /><br /><br />
<input type="submit" value="Submit" />
</form>

<br /><br />

<?php

if ( isset($_POST['user']) AND isset($_POST['password']) ) {
    require_once 'config.inc.php';

    $user = $_POST['user'];
    $pass = $_POST['password'];

    $sql = "select username,password from users where username = '$user' and password = '$pass';";
    $result = $conn->query($sql);

#    if ($conn->error)
#    {
#        echo "Error: " . $conn->error . "\n";
#    }


    if ($result->num_rows > 0) {
        echo "Welcome $user";
    }
    elseif ($result->num_rows == 0)
    {
        echo "username or password invalid";
    }

    echo "<br />\n";

    $conn->close();

}
?>

<br />
<br />
