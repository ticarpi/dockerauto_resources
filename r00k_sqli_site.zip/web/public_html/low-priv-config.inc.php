<?php
    $server = "db";
    $user = "directory_user";
    $pass = "user_foobar";
    $db = "t_web_app";

    //create connection
    $conn = new mysqli($server, $user, $pass, $db);

    //check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }